#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "administrador.h"

#include "menus.h"
#include "Producto.h"

Producto anadirProducto(ListaProductos *lp){
return 0;
}
Producto buscarProducto(ListaProductos lp){
	return 0;
}
Producto modificarProducto(Producto *p){
	return 0;
}
void modificarNombre(Producto *p){

}
void modificarDescripcion(Producto *p){

}
void modificarCantidad(Producto *p){

}
void modificarPrecio(Producto *p){

}
Producto eliminarProducto(Producto p, ListaProductos *lp){
	return 0;
}
