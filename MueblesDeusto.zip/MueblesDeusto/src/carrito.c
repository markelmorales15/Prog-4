/*
 * carrito.c
 *
 *  Created on: 26 mar 2023
 *      Author: marke
 */

void mostrarCarrito(Carrito c);//ver carrito de compra
void EliminarProductoCarrito(Producto *lista, char *nombre);//el puntero de nombre no es 100% correcrto, hasta que se pergunte a marian
void AniadirProducto(Producto *lista, Producto p);
