/*
 * DUDA: Hacer submenús aquí o en las funciones directamente?
 */

#ifndef MENUS_H_
#define MENUS_H_

int menuInicio();
int menuAdmin();
int menuCliente();

void inicioSesion();

//Sub menús administrador


#endif /* MENUS_H_ */
